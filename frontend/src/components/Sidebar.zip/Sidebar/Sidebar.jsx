import { NavLink, useNavigate } from "react-router-dom"; 
import "./Sidebar.css";


function Sidebar() {
  const navigate = useNavigate(); 

  const handleLogout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    navigate("/"); 
  };

  return (
    <aside className="sidebar">
      {/* Top Section: Logo and Navigation */}
      <div className="sidebar-top">
        <div className="logo">
          <h2>Python Academy</h2>
        </div>

        <nav>
          <NavLink to="/dashboard" className="nav-item">
            🏠 Dashboard
          </NavLink>

          <NavLink to="/my-courses" className="nav-item">
            📚 My Courses
          </NavLink>

          {/* <NavLink to="/certificates" className="nav-item">
            🎓 Certificates
          </NavLink> */}

          <NavLink to="/certificates" className="nav-item">
            🎓 Certificates
          </NavLink>

          <NavLink to="/profile" className="nav-item">
            👤 Profile
          </NavLink>

          <NavLink to="/settings" className="nav-item">
            ⚙️ Settings
          </NavLink>
        </nav>
      </div>

      {/* Bottom Section: Logout Button */}
      <div className="sidebar-bottom">
        <button onClick={handleLogout} className="logout-btn">
          🚪 Logout
        </button>
      </div>
    </aside>
  );
}

export default Sidebar;